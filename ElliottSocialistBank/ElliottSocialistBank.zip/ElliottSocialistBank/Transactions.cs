﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ElliottSocialistBank
{
    class Transactions
    {
        public static List<int> transactionMoney = new List<int>();
        public string name { get; set; }
        public static List<string> transacitionTime = new List<string>();

        
    }
}
